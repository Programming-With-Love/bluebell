module.exports = {
    assetsDir: "static",
    devServer: {
        proxy: {
            '/api/v1': {
              target: 'http://112.126.78.122:8084',
              changeOrigin: true,
            }
        }
    }
  }
